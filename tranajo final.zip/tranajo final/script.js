let currentLab = "";
let currentQuestion = "";
let currentBase = {};  // Variable para almacenar la base de conocimiento actual

const knowledgeBaseComputadoras = {
    "El equipo enciende": {
        "si": "¿El sistema operativo carga correctamente?",
        "no": "Verifique la conexión de energía o revise la fuente de alimentación."
    },
    // Otras preguntas...
};

const knowledgeBaseRedes = {
    "¿Hay conexión a internet?": {
        "si": "¿Todos los dispositivos pueden acceder a la red?",
        "no": "Verifique el router, los cables o el servicio de internet."
    },
    // Otras preguntas...
};

function startDiagnosis(base, firstQuestion) {
    currentQuestion = firstQuestion;
    showQuestion(currentQuestion);
}

function showQuestion(question) {
    document.getElementById("question").textContent = question + "?";
    document.getElementById("answers").innerHTML = `
        <button onclick="answer('si')">Sí</button>
        <button onclick="answer('no')">No</button>
    `;
    document.getElementById("result").textContent = "";
}

function answer(response) {
    const next = currentBase[currentQuestion][response];
    if (next in currentBase) {
        currentQuestion = next;
        showQuestion(currentQuestion);
    } else {
        document.getElementById("result").textContent = next;
        document.getElementById("question").textContent = "";
        document.getElementById("answers").innerHTML = "";
    }
}

// Al cargar la página de diagnóstico, seleccionar la base correspondiente
window.onload = function() {
    const currentPage = window.location.pathname.split('/').pop();
    if (currentPage === 'laboratorio_computadoras.html') {
        currentBase = knowledgeBaseComputadoras;
        startDiagnosis(currentBase, "El equipo enciende");
    } else if (currentPage === 'laboratorio_redes.html') {
        currentBase = knowledgeBaseRedes;
        startDiagnosis(currentBase, "¿Hay conexión a internet?");
    }
};
